# Assignment 13: Data Gathering, Preprocessing & EDA

## Overview
This assignment focuses on collecting data from different sources, understanding and cleaning datasets, preparing features, and performing Exploratory Data Analysis (EDA) using Python.

## Objectives
- Load data from CSV and JSON files.
- Retrieve structured data from an SQLite database.
- Explore API-based data collection.
- Understand dataset structure, data types, and missing values.
- Clean and preprocess the dataset.
- Prepare features using date conversion and one-hot encoding.
- Perform univariate and bivariate analysis.
- Visualize data using Matplotlib and Seaborn.
- Identify patterns, outliers, and relationships in the data.

## Tasks Completed

### Task 1: Load CSV Data
Loaded sales data from a CSV file using Pandas.

### Task 2: Load JSON Data
Loaded and explored product data stored in JSON format.

### Task 3: Load Data from SQLite
Connected to an SQLite database and retrieved employee records.

### Task 4: API Data Collection
Attempted to access popular movie data using The Movie Database (TMDB) API. Access was unsuccessful due to a network connectivity issue.

### Task 5: Understanding Data
Explored the dataset's dimensions, column names, data types, numerical and categorical columns, and missing values.

### Task 6: Data Cleaning
Handled missing values, removed duplicate records, standardized column names, and saved the cleaned dataset as `sales_data_cleaned.csv`.

### Task 7: Feature Preparation
Converted the date column to datetime format, separated the target column (`sales_channel`) from the features, and applied one-hot encoding to categorical feature columns.

### Task 8: Univariate Analysis
Visualized individual variables using histograms, KDE plots, count plots, and boxplots. Also explored the number of records by sale date.

### Task 9: Bivariate Analysis
Explored relationships between variables using scatter plots, correlation heatmaps, bar plots, boxplots, and a categorical cross-tabulation heatmap.

### Task 10: Insights and Observations
Examined dataset size, missing values, duplicate records, frequent categorical values, unique values, and records by date to identify meaningful observations.

## Technologies Used
- Python
- Pandas
- Matplotlib
- Seaborn
- SQLite
- Jupyter Notebook
- Visual Studio Code

## Files
- `sales_data.csv` — Original sales dataset.
- `sales_data_cleaned.csv` — Cleaned sales dataset.
- `products.json` — Product data in JSON format.
- `sample.db` — SQLite database containing employee records.
- `README.md` — Project documentation.

## Key Learnings
- Data collection from different sources.
- Data exploration and preprocessing.
- Handling missing values and duplicate records.
- Feature preparation and categorical encoding.
- Creating visualizations for univariate and bivariate analysis.
- Interpreting data patterns and identifying potential outliers.

## Conclusion
This assignment provided practical experience in data gathering, data cleaning, feature preparation, and exploratory data analysis using Python. The prepared dataset and visualizations help reveal patterns and relationships that may be useful in future machine learning projects.

**Note:** This assignment focuses on data preparation and exploratory data analysis. Model training was not performed.